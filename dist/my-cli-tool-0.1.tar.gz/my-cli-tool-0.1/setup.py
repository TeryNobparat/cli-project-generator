from setuptools import setup, find_packages

setup(
    name="my-cli-tool",
    version="0.1",
    py_modules=["cli_project_generator"],
    install_requires=[
        "sqlalchemy",
        "pydantic",
        "fastapi",
        "uvicorn",
    ],
    entry_points={
        "console_scripts": [
            "nb=cli_project_generator:main",
        ],
    },
)
